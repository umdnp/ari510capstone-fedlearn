"""
Federated Learning module for ARI 510 Capstone Project.

This package contains reusable code for federated learning experiments
on the eICU dataset.
"""

__version__ = "0.1.0"
